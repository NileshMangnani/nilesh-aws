package com.capgemini.payroll.main;

import com.capgemini.payroll.beans.Associate;
import com.capgemini.payroll.beans.BankDetails;
import com.capgemini.payroll.beans.Salary;

public class MainClass {

	private static final Object[]  = null;

	private static void main(String[] args) {
		// TODO Auto-generated method stub
		Associate associate= new Associate( 102,15000,"Nilesh","Mangnani","YPT","Software Associate","xyz","nilesh@capgemini.com" );
		System.out.println( associate.getAssociateID()+" "+associate.getFirstName()+" "+associate.getLastName());
		
		BankDetails bankDetails= new BankDetails( 1200000, "bankName","ifscCode");
		System.out.println( bankDetails.getAccountNumber()+" "+bankDetails.getBankName());
		
		Salary salary= new Salary( 1000, 100, 123, 321, 111, 101, 101, 10, 10, 123.00, 100.00);
		System.out.println( salary.getBasicSalary()+" "+salary.getCompanyPf());
		
		int [] a={1,2,3,4,8,6};
		for (int i=1; i<a.length; i++)
		{
			if (a[i]==8)
				System.out.println("Search number found on"+a[i]);
			else
				//System.out.println("Not Found");
				continue;
		}

		Associate [] associates= new Associate[3];
		associates[0]= new Associate(101, 15000, "Satish","Medaf","YTP","Sr Con","HJF","Ca@de.com");
		associates[1]= new Associate(101, 15000, "Satish","Medaf","YTP","Sr Con","HJF","Ca@de.com");
		
		for (int i=0;i < associates.length;i++)
			System.out.println (associates[i].getAssociateID()+" "+associates[i].getFirstName()+" "+associates[i].getLastName());
		
	}

}
