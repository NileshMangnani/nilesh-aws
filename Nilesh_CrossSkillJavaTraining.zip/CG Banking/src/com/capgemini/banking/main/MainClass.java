package com.capgemini.banking.main;

import com.capgemini.banking.beans.Customer;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer customer= new Customer( 111,"Nilesh","lastName",999999,"emailId","11111","1111","23:23:23");
	}

}
